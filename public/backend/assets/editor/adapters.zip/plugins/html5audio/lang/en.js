﻿CKEDITOR.plugins.setLang( 'html5audio', 'en', {
    button: 'Insert HTML5 audio',
    title: 'HTML5 audio',
    infoLabel: 'Audio info',
    urlMissing: 'Audio source URL is missing.',
    audioProperties: 'Audio properties',
    upload: 'Upload',
    btnUpload: 'Send it to the server',
    advanced: 'Advanced',
    autoplay: 'Autoplay?',
    yes: 'Yes',
    no: 'No'
} );
